<?php

namespace App\Http\Controllers;

use Illuminate\Http\request;

class UsangController extends Controller
{
    public function index()
    {
        echo "ini dari index
        punyaknya usang controller";
    }

    public function godog()
    {
        echo "jadinya telo godog";
    }
}